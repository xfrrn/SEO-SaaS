# 事件与后端上下文协议 v1

浏览器每个事件包含 `schema_version:1`、UUID `event_id`、`site_id`、`event_type`、`capture_origin`、UTC ISO `occurred_at`、`environment` 和 `sdk_version`。`capture_origin` 仅为 `sdk` 或 `plausible_mirror`，不是访问渠道，也不是可信身份。完整 TypeScript 类型见 `src/types.ts`；接收校验见 `collector/schema.ts`。

`site_id` 为 1–64 个字符，首字符必须为英文字母或数字，其余允许字母、数字、点、下划线和连字符（例如 `tools.example`）。SDK 初始化和归因模块遵循同一规则。

两个写入接口都接收 `{events:[...]}`，成功返回 `{accepted,duplicates}`：二者均为非负整数，总和必须等于提交条数。SDK 只有在收到有效回执后才移出队列并增加 `delivered`；HTML 200、缺字段或条数不匹配会记录 `collector_invalid_receipt` 并按原事件 ID 有限重试。此约定仅用于自有 Collector，Plausible 仍使用官方发送机制。

```json
{
  "schema_version": 1,
  "event_id": "97b8a5c4-1ff6-423d-bde7-965da2d21d3c",
  "site_id": "demo",
  "event_type": "tool_completed",
  "capture_origin": "sdk",
  "occurred_at": "2026-10-08T09:00:00.000Z",
  "environment": "production",
  "sdk_version": "0.1.0",
  "page": {"url": "https://tools.example/"},
  "context": {},
  "props": {"tool": "webp-to-png", "result": "success"}
}
```

`page`、`context`、`props` 可选；SDK 产生的事件在入队前固定这些字段。Collector 与 Plausible 各自生成新对象，修改调用参数、SPA 跳转、稍后登录都不会修改旧队列。镜像优先使用 Hook 的 URL/referrer，仅把白名单事件送入 Collector，不经过业务分发入口。Collector 不按 URL/相近时间去重，仅按 `(site_id,event_id)` 去重；重试保留 UUID。

页面 URL 默认去除账号信息、全部查询、片段，并将未列入 `privacy.allowedPaths` 的路径变成 `/[redacted]`。只允许把不含用户数据的固定公共路径放入列表。referrer 仅保留主机。props 同时经过事件字段白名单、敏感字段/值检查和可选 `privacy.propValues` 枚举。正则不是通用 PII 检测：外部文本必须使用有限枚举；不把姓名、评论、搜索词、文件名、表单内容等放入属性。

Plausible 专用 URL 可以通过 `privacy.campaignValues` 保留经过审核的本次访问 UTM/ref/source 值；Collector 页面 URL 仍去掉全部查询。它不会读取/覆盖为自有 first_touch。未允许的 campaign 值会被删除，因此上线前需配置真实的有限广告渠道字典并验收报表。

归因上下文形状：

```typescript
{
  schema_version: 1,
  site_id: 'my-site',
  // 仅开启身份 + 存储 + Collector 许可时存在：
  visitor_id?: 'UUID',
  session_id?: 'UUID',
  attribution?: {
    current_touch?: Touch,
    first_touch?: Touch,
    last_non_direct_touch?: Touch
  }
}
// Touch: {kind:'campaign'|'referral'|'unknown', occurred_at, landing_page,
//         referrer_host?, utm?: {utm_source?,utm_medium?,utm_campaign?,utm_content?,utm_term?}}
```

浏览器事件 `context.attribution` 使用内层对象，不重复存 schema/site。`getAttributionContext()` 是给业务请求使用的外层桥接协议；身份模块关闭时不生成任何 ID。身份开启后 session_id 只在本次文档生命周期内有效，visitor_id 可按 session/local 与 TTL 保存，命名空间包含站点和当前 origin；没有跨域或跨设备识别。

归因创建于许可后的当前文档访问；SPA 不改变此次访问的来源。内部 referrer 不成为获客来源，无 referrer 保留 unknown；首次来源在 TTL 内不覆盖，unknown 回访不覆盖最近非直接来源；后者受 windowMs 与 TTL 双重限制。排除回调路径前缀和认证/支付 referrer 后，不以它们建立新的 touch。持久化默认 none，可选 session/local；无存储权限或存储失败则内存降级。返回副本，撤回清除两种存储和待发队列。没有完整浏览轨迹。

可信后端使用独立 `/v1/server-events` + Bearer 凭证，`capture_origin:'backend'`，可带 `identity:{user_id,order_id?}`。凭证确定允许站点、事件与查询权限；浏览器不能通过更改 JSON 变成可信发送者。查询返回 `{event,received_via,received_at}`，应以 `received_via` 判定真实入口。监控事件不可作为付款、权限或余额凭据。

`monitor-analytics-sdk/server` 的 `sendConfirmedPayment()` 固定产生 `payment_confirmed`，要求 `identity.user_id` 与 `identity.order_id`；`props` 仅有 `amount` 和 `currency`。`amount` 是币种最小单位的非负安全整数（USD 9.90 → 990），币种为三位大写字母。支付确认和监控 `event_id` 都由真实后端保存，发送函数不验证支付签名、不执行扣款；同一实际付款重试保持 ID 不变。
