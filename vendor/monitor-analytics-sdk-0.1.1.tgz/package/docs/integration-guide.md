# 导入、函数与事件调用指南

适用版本：`monitor-analytics-sdk@0.1.0`。当前名称是 `monitor`，HTML 全局对象是 `window.monitor`，配置是 `window.monitorConfig`，不要再使用早期的 `actify` 名称。

## 1. 哪些内容放在哪里

| 位置 | 需要放入的内容 | 不需要放入的内容 |
|---|---|---|
| 普通 HTML 网站 | 构建后的整个 `dist/`、站点配置、业务调用代码 | Collector 源码、数据库、服务端密钥 |
| React / Vue 等前端项目 | 安装 SDK 包，在客户端入口初始化 | 不必另外手动插入 Plausible 脚本 |
| 监控服务器 | Collector 服务、站点白名单、数据库、鉴权配置 | 网站业务组件 |
| 业务后端（可选） | 真实注册/支付事件、归因关联代码、服务端凭证 | 不依赖浏览器事件判断支付或权限 |

前端 SDK 负责发送，Collector 负责接收。仅填写 URL 不会自动部署接收服务。

## 2. 普通 HTML：复制构建文件接入

在 SDK 仓库根目录执行（需要 Node.js 24+）：

```sh
npm ci
npm run build
```

将整个 `dist/` 复制到网站的 `/analytics/` 目录，保留结构：

```text
网站静态目录/
└── analytics/
    ├── monitor.js       # HTML 入口
    ├── index.js         # ESM 导入入口
    └── chunks/          # 自动加载的核心和可选模块，不能删除/改名
```

下面是只接 Collector 的完整最小 HTML 示例。替换接收地址，并先在服务端登记相同的站点、事件和路径。示例假设已根据网站实际许可状态允许 Collector 采集；需要等待用户许可时，将 `collector: true` 改为 `false`，获准后调用 `setConsent()`。

```html
<!doctype html>
<html lang="zh-CN">
<meta charset="utf-8">
<title>我的工具站</title>
<button id="complete" disabled>模拟完成一次工具操作</button>

<script>
window.monitorConfig = {
  siteId: 'my-tool',
  environment: 'production',
  collector: {
    endpoint: 'https://metrics.example.com/v1/browser-events',
    events: { tool_completed: ['tool', 'result'] }
  },
  privacy: {
    allowedPaths: ['/', '/tools/webp-to-png'],
    propValues: { tool: ['webp-to-png'], result: ['success', 'failure'] }
  },
  consent: { collector: true }
};
</script>

<script type="module">
// 显式等待入口加载，避免业务脚本先于 window.monitor 执行。
await import('/analytics/monitor.js');
await window.monitor.ready();
const button = document.getElementById('complete');
button.disabled = false;
button.addEventListener('click', () => {
  window.monitor.track('tool_completed', {
    tool: 'webp-to-png', result: 'success'
  });
});
</script>
</html>
```

实际网站应在转换成功/失败的业务结果位置调用 `track()`，而不是仅凭点击按钮就认定成功。SDK 的加载与初始化放在统一入口；如果第三方脚本失败，应保持真实工具自身可用。上面的 disabled 按钮仅用于演示加载顺序。

也可使用 `<script type="module" src="/analytics/monitor.js"></script>` 加载，但后续调用必须等它执行完成，不能在紧随其后的普通同步脚本中直接假设 `window.monitor` 已存在。不要两种方式重复配置。文件通过 HTTPS 或 localhost 提供，不要直接双击 HTML 使用 `file://`。

现成的本地双链路示例见 [static.html](../examples/static.html)，运行 `npm run demo` 后打开 `http://127.0.0.1:4173`。它使用真实 Collector 和模拟 Plausible 接口，不是生产配置。

## 3. React / Vue 等项目：安装包后导入

当前仓库标记 `private:true`，没有在本次工作中发布 npm 包。不要直接假定公共 registry 已存在同名包。

先在 SDK 仓库中构建、打包：

```sh
npm ci
npm run build
npm pack
```

得到 `monitor-analytics-sdk-0.1.0.tgz` 后，复制到前端项目根目录，在该项目中执行：

```sh
npm install ./monitor-analytics-sdk-0.1.0.tgz
```

新建前端项目的 `src/monitoring.ts`：

```typescript
import { monitor, type Config } from 'monitor-analytics-sdk';

const config: Config = {
  siteId: 'my-tool',
  environment: 'production',
  collector: {
    endpoint: 'https://metrics.example.com/v1/browser-events',
    events: { tool_completed: ['tool', 'result'] }
  },
  privacy: {
    allowedPaths: ['/', '/tools/webp-to-png'],
    propValues: { tool: ['webp-to-png'], result: ['success', 'failure'] }
  },
  consent: { collector: false }
};

export async function startMonitoring(collectorAllowed: boolean) {
  monitor.init(config);
  await monitor.setConsent({ collector: collectorAllowed });
}

export function reportToolCompleted(result: 'success' | 'failure') {
  monitor.track('tool_completed', { tool: 'webp-to-png', result });
}
```

从 React 根组件的客户端 effect 或 Vue 根组件的 mounted 生命周期调用 `startMonitoring(实际许可状态)`；业务完成时调用 `reportToolCompleted('success')`。不要在每次渲染时创建不同配置。SSR 导入是安全的，但服务器端调用不会采集，也不会替浏览器完成初始化。同页面重复使用相同配置会复用单例；换站点或配置需要新的页面生命周期，许可变化使用 `setConsent()`。

项目安装包的方式无需再复制 `dist/` 到 public：前端构建工具负责处理导入和动态模块。更多模块配置见 [framework.ts](../examples/framework.ts)。

## 4. 地址和白名单在哪里填写

| 配置字段 | 填写内容 | 示例 / 注意事项 |
|---|---|---|
| `siteId` | Collector 登记的公开站点标识 | `my-tool`；不是密钥 |
| `environment` | 当前环境 | `production` / `staging` / `development` |
| `collector.endpoint` | 浏览器接收 API | `https://metrics.example.com/v1/browser-events`，不是普通网页 |
| `collector.events` | 本站允许发出的事件及属性名 | `{ tool_completed: ['tool', 'result'] }` |
| `privacy.allowedPaths` | 可保留的固定公开路径 | 未列出的路径变成 `/[redacted]`；查询和片段被移除 |
| `privacy.propValues` | 属性可接受的有限值 | 外部文本使用枚举，不放邮箱、订单号、文件名或用户输入 |
| `plausible.domain` | Plausible 后台登记的被监控网站 | `tools.example.com`，不带 `https://` |
| `plausible.endpoint` | Plausible Events API | 托管版默认 `https://plausible.io/api/event`；自部署填自己的绝对地址 |
| `modules` | 是否启用归因、身份、错误、性能能力 | 启用模块还需要对应许可 |
| `consent` | 对应目的地、模块和存储的许可状态 | 未填写的许可全部为 `false` |

Collector 服务端同时修改 [config.example.json](../collector/config.example.json) 中的 `sites`。以下是站点配置片段，替换进完整配置，不要覆盖其他站点和后端凭证：

```json
{
  "my-tool": {
    "origins": ["https://tools.example.com"],
    "allowedPaths": ["/", "/tools/webp-to-png"],
    "browserEvents": {
      "tool_completed": ["tool", "result"]
    }
  }
}
```

这里的 `my-tool` 必须对应前端 `siteId`，`origins` 是实际访问网站的 origin，含协议及必要端口。前端增加事件后，服务端 `browserEvents` 也要允许；否则 Collector 会拒绝整个不合规批次。服务端凭证只留在服务端。部署和查询见 [Collector 文档](../collector/README.md)。

## 5. 公开函数对照表

HTML 使用 `window.monitor`，模块项目使用导入的 `monitor`；以下函数相同。

| 函数 | 用途 | 返回值 | 调用时机 / 条件 |
|---|---|---|---|
| `monitor.init(config)` | 校验配置、初始化页面单例 | SDK 客户端对象 | 客户端统一入口；非法/冲突配置会抛错 |
| `monitor.ready()` | 等待当前模块初始化任务结束 | `Promise<void>` | 读取完整归因前建议等待；任务完成不等于每个模块都成功 |
| `monitor.track(name, props?)` | 记录自定义业务事件 | `void` | 在真实业务动作发生时；事件需列入白名单 |
| `monitor.getAttributionContext()` | 获取归因与允许使用的匿名上下文副本 | `AttributionBridge` 或 `undefined` | 归因配置和许可启用后，随注册/订单请求传给后端 |
| `monitor.setConsent(partialState)` | 更新部分许可、停止/启动对应能力 | `Promise<void>` | 许可变更时；未列出的许可保持原值 |
| `monitor.recordPerformance(metric, value)` | 记录已经测得的性能指标 | `void` | 开启性能模块及许可；`metric` 仅 `LCP` / `CLS` / `INP` |
| `monitor.flush()` | 尝试发送 Collector 当前批次 | `Promise<void>` | 调试或主动刷新；剩余批次继续调度，不保证网络送达 |
| `monitor.getDiagnostics()` | 查看模块、许可、队列和有限诊断 | 诊断对象或 `undefined` | 初始化后排查问题；未初始化时为 `undefined` |

也可 `import { init, SDK_VERSION } from 'monitor-analytics-sdk'`，使用 `const sdk = init(config)` 返回的对象调用其余方法。没有 `identify()`、`login()`、`pay()` 或手动 `pageview()` 函数。未初始化时 `monitor.track()` 不会缓存调用，必须先初始化。

## 6. 事件对照表：哪些可以手动调用

`track()` 不是固定事件枚举。`tool_completed`、`signup_completed` 是现有示例约定，其他业务名称也可以自行配置；`pageview`、`error`、`performance` 等由指定采集路径负责，不能用普通 `track()` 冒充。

| 事件名 | 类别 | 调用函数 / 产生方式 | 允许属性示例 | 目的地及启用条件 |
|---|---|---|---|---|
| `tool_completed` | 自定义业务事件，现有示例 | `monitor.track('tool_completed', { tool: 'webp-to-png', result: 'success' })` | `tool`, `result` | Collector；配置映射后可再发 Plausible `Tool Completed` |
| `signup_completed` | 浏览器分析事件，现有示例 | `monitor.track('signup_completed', { method: 'email' })` | `method` | Collector；配置映射后可再发 Plausible `Signup`；不是可信注册凭证 |
| `download_completed` | 可自行新增的业务事件，默认未配置 | `monitor.track('download_completed', { format: 'png' })` | `format` | 先配置前后端白名单；默认不发 Plausible |
| `pageview` | 官方自动采集的镜像 | 不手动调用；Plausible 自动事件通过 Hook 镜像 | 第一版镜像不复制 props | 原事件发 Plausible，镜像发 Collector；需要可用 Plausible 配置和各自许可 |
| `error` | SDK 可选自动采集 | 开启后监听 `error` / `unhandledrejection`，不调用 `track('error')` | `kind`, `error_type` | 仅 Collector；配置错误模块、许可和事件白名单 |
| `performance` | SDK 手动性能扩展 | `monitor.recordPerformance('LCP', 1200)` | 自动构造 `metric`, `value` | 仅 Collector；配置性能模块、许可和事件白名单 |
| `signup_confirmed` | 可信后端事件 | 后端导入 `monitor-analytics-sdk/server`，调用 `sendConfirmedRegistration(record, destination)` | `method`；身份放独立 `identity` 字段 | 仅鉴权的 `/v1/server-events`；不是前端 SDK 方法 |
| `payment_confirmed` | 可信后端付款事件 | 后端导入 `monitor-analytics-sdk/server`，调用 `sendConfirmedPayment(record, destination)` | `currency`, `amount`（最小货币单位整数）；用户/订单放 `identity` | 后端确认付款后发送；不转发 Plausible；[完整示例](backend.md#专门的付款事件函数) |
| `engagement` | Plausible 内部自动事件 | 不使用 SDK 手动发送或镜像 | SDK 不接收该事件属性 | 官方内部行为；绕过镜像 Hook，不支持配置为镜像事件 |

所有目的地发送都以对应许可和有效配置为前提。`track()` 对保留事件及部分保留名称前缀会拒绝并记录 `reserved_event`；不要用浏览器事件模拟身份绑定、订单或支付事实。Plausible 映射还会禁止错误、性能、身份、付款等类别。

`signup_completed` 仅在真实新注册完成时触发一次，不在每次登录、刷新成功页时触发。后端 `signup_confirmed` 使用后端生成并持久化的 eventId 重试，不与浏览器事件混为一条记录。[后端接入示例](../examples/backend.ts)

性能值由接入方实际测量：LCP / INP 使用毫秒，CLS 使用无单位分数。SDK 不自动计算这些指标；传入值必须有限、非负且不超过 3,600,000。不要把示例 `1200` 当成真实采样值。

## 7. 新增自己的事件：需要配置三处

例如需要 `download_completed`：

1. 在初始化前，把前端事件白名单设为 `collector.events.download_completed = ['format']`，并配置 `privacy.propValues.format = ['png', 'webp']`。
2. 在 Collector 对应站点中增加 `browserEvents.download_completed = ['format']`，重新加载服务配置（当前服务通过重启加载配置）。
3. 在真实业务完成时调用：

```javascript
monitor.track('download_completed', { format: 'png' });
```

不需要为每个事件新增一个 SDK 函数。没有列入前端白名单的事件不会进入 Collector；未允许的属性会被移除。事件时间、UUID、页面和上下文由 SDK 自动补充，不要自行传 user_id、visitor_id、邮箱或订单标识。

若还需要发送 Plausible，再在初始化配置的 `plausible.customEvents` 中添加映射，并在 Plausible 后台创建同名 Custom Event Goal：

```javascript
customEvents: {
  download_completed: {
    name: 'Download Completed',
    allowedProps: ['format']
  }
}
```

映射的 allowedProps 也必须是该事件 Collector 属性白名单的子集。不配置映射就只发 Collector；发送事件不会自动创建 Goal。

## 8. Plausible 可选接入与当前限制

在 `init()` 前增加如下配置片段，同时在前端 `collector.events` 和服务端 `browserEvents` 中允许 `pageview: []`、`tool_completed: ['tool', 'result']`：

```javascript
plausible: {
  domain: 'tools.example.com',
  endpoint: 'https://plausible.io/api/event',
  trackerVersion: '0.4.6',
  consentMode: 'strict',
  mirrorEvents: ['pageview'],
  customEvents: {
    tool_completed: { name: 'Tool Completed', allowedProps: ['tool', 'result'] }
  }
}
```

对应许可为 `consent.plausible`。**当前官方 0.4.6 的 engagement 绕过 Hook，没有公开完整停止接口，因此 strict 即使取得许可也不会启动它。** 只有接受页面生命周期模式的明确限制时，才显式改为 `page-lifetime`；撤回后官方可能仍发送 engagement。要保证完整即时撤回，请保留 strict，不能把 page-lifetime 当作等价替代。详见 [兼容性说明](compatibility.md)。

先移除原有 Plausible 标签、框架插件或重复初始化入口，并迁移已有 `transformRequest` 隐私过滤函数。不要额外调用 `plausible('pageview')`；它会重复计数。自部署服务端与实际报表仍需单独联调。

## 9. 模块、许可与归因示例

| 能力 | 初始化前的模块配置 | 需要的许可 | 还需要什么 |
|---|---|---|---|
| 自有业务事件 | 无额外模块 | `collector: true` | 两端事件白名单 |
| 归因线索 | `modules.attribution: { persistence: 'none' }` | `attribution: true` | 可选配置 `utmAllowlist`，只保留审核过的 campaign 值 |
| 归因持久化 | attribution 的 persistence 为 `session` / `local` | 另加 `storage: true` | 可配置 TTL 和归因窗口；未许可存储则内存降级 |
| 匿名标识 | `modules.identity: { persistence: 'session' }` | `identity`, `storage`, `collector` 均为 true | 默认关闭，不代表已认证 user_id |
| 错误采集 | `modules.errors: true` | `errors`, `collector` 均为 true | 两端 `error: ['kind', 'error_type']`；每分钟最多 10 条 |
| 性能扩展 | `modules.performance: true` | `performance`, `collector` 均为 true | 两端 `performance: ['metric', 'value']`；调用 recordPerformance |

启用归因后，先等待初始化，再将线索随业务请求传给已有后端：

```javascript
await monitor.ready();
const attribution = monitor.getAttributionContext();
// 将 attribution 加入既有注册/订单请求；不要替换 OAuth state 或身份校验。
```

该方法只读取上下文，不自动发事件，也不完成登录或用户绑定。真实用户和站点由后端认证确定。[后端协议说明](backend.md)

更新部分许可时只传要改变的字段；如需全部撤回，应明确传入全部许可位：

```javascript
await monitor.setConsent({
  collector: false, plausible: false, attribution: false, storage: false,
  identity: false, errors: false, performance: false
});
```

自有队列与对应存储会清理，错误监听停止。已经到达服务端的数据不会因此自动删除；Plausible 的 page-lifetime 模式仍有上述限制。

## 10. 确认接入是否成功

```javascript
monitor.track('tool_completed', { tool: 'webp-to-png', result: 'success' });
await monitor.flush();
console.log(monitor.getDiagnostics());
```

| 现象 | 优先检查 |
|---|---|
| `window.monitor` 不存在 | monitor.js/chunks 是否正确部署、是否使用 type=module、是否等待加载完成 |
| 调用后 Collector 没有请求 | 是否先 init、collector 许可是否为 true、事件是否列入前端白名单；默认还会批量等待约 5 秒 |
| Collector 返回 400 / 403 | 站点、Origin、两端事件/属性/路径白名单是否一致 |
| 属性消失 | 是否命中字段/值白名单、敏感信息过滤；属性值不能是对象/数组 |
| Plausible 显示 `unsupported_consent` | strict 拒绝当前官方版本，是明确的兼容限制 |
| Plausible 显示 `migration_required` | 页面已存在官方脚本或全局对象，先迁移旧入口 |
| 归因返回 undefined / 暂缺 touch | 是否启用归因及许可、是否 await ready、当前页面是否被配置排除 |

最后通过鉴权查询 `/v1/events?site_id=my-tool&limit=20` 确认实际入库；查询 token 只在服务端或受控调试工具使用。Plausible 则需要检查真实测试站的过滤信息和目标报表，不能仅凭 HTTP 202 判定成功。
