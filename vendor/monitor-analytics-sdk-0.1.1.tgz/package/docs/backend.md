# 与通用 Backend SDK 对接

通用后端已在 better-auth 仓库的 Business 插件中集成。监控包通过 `monitor-analytics-sdk/server` 提供归因线索校验、注册与付款发送函数，可由现有业务后端直接导入。已与 `SEO-Worker/apps/collectors/monitor` 接收服务联调注册与付款协议、鉴权和实际入库，后端 SDK 提供独立安装包与真实 Collector 的集成测试；商户支付沙箱仍需单独验收。

浏览器注册/创建订单请求中加入 `monitor.getAttributionContext()`；不传自称可信的 user_id。业务后端从既有认证会话和路由/租户确定站点与用户，调用 `registrationClues(submitted, serverSiteId, allowedPublicPaths, siteOrigins)` 验证并在**真实注册事务中**保存归因。路径和来源白名单使用接收端相同的服务端站点配置，不由请求提供。默认路径仅根路径和脱敏路径；省略 `siteOrigins` 不会在示例里检查来源，实际 Monitor 接收端仍会检查，因此应始终传入。无效监控线索会被丢弃，不能阻止注册。

```typescript
import { sendConfirmedRegistration } from 'monitor-analytics-sdk/server';

// site 来自业务后端的站点配置，与接收端 MONITOR_SITES_JSON 保持一致。
await sendConfirmedRegistration(committedRecord, {
  endpoint: 'https://metrics.example.com/v1/server-events',
  token: process.env.MONITOR_BACKEND_TOKEN!,
  allowedPaths: site.allowedPaths,
  origins: site.origins,
});
```

示例同时拒绝不规范 URL、超过 100 字符或包含敏感值的 UTM。发送成功须收到 `{accepted:1, duplicates:0}` 或 `{accepted:0, duplicates:1}`；无效回执抛出错误，由已有 outbox 保留待重试记录。

`sendConfirmedRegistration()` 只接受已经提交的注册记录，发送到鉴权入口；旧的 `examples/backend.ts` 导入路径保留为兼容转出。使用既有 transactional outbox/任务机制保存 `eventId`、首次业务时间和重试状态；重试保留 eventId。发送函数不会自行重试整个注册，也不会重建认证或支付系统。没有 outbox 时可先记录发送失败，再由已有后台重试，避免把监控故障传播为业务失败。

## 专门的付款事件函数

在已验签支付回调、主动查询支付结果或其他可信后端流程确认付款、提交业务记录之后，从已有 outbox/任务中调用：

```typescript
import { sendConfirmedPayment } from 'monitor-analytics-sdk/server';

// payment 来自已确认的后端付款记录；eventId 在该记录/任务创建时生成并持久化。
await sendConfirmedPayment({
  siteId: payment.siteId,
  userId: payment.userId,
  orderId: payment.orderId,
  eventId: payment.monitorEventId,
  occurredAt: payment.confirmedAt.toISOString(),
  amount: payment.amountMinor, // 例如 USD 9.90 传 990
  currency: payment.currency, // 例如 USD
  attribution: payment.savedAttribution,
}, {
  endpoint: 'https://metrics.example.com/v1/server-events',
  token: process.env.MONITOR_BACKEND_TOKEN!,
  allowedPaths: site.allowedPaths,
  origins: site.origins,
});
```

| 输入字段 | 含义 / Collector 字段 |
|---|---|
| `siteId` | 后端确认的站点 → `site_id` |
| `userId`、`orderId` | 后端确认的用户和订单 → `identity.user_id`、`identity.order_id` |
| `eventId` | 这一次实际付款的持久化 UUID → `event_id`，重试不重新生成 |
| `occurredAt` | 真实确认时间，UTC 毫秒 ISO → `occurred_at` |
| `amount` | 非负安全整数，最小货币单位 → `props.amount`，不做汇率或小数转换 |
| `currency` | 三个大写货币字母 → `props.currency` |
| `attribution` | 可选的完整浏览器桥接协议，校验后仅其内层放入 `context` |
| `environment` | 可选，默认 `production`；测试可用 `staging` / `development` |

函数固定生成 `event_type:'payment_confirmed'`、`capture_origin:'backend'`。发送前验证必填字段、金额和币种；额外字段不会透传。Collector 写入凭证需配置 `payment_confirmed: ['amount', 'currency']`，已有 Monitor 接收端示例已包含它。归因来源和路径仍按该站点配置校验，无效可选线索丢弃。

返回 `{accepted, duplicates}`；超时（5 秒）、HTTP 错误和无效回执会拒绝 Promise，由现有后台任务记录并有限重试。重复 webhook 使用相同 `eventId`；同一订单的不同真实付款（例如分期）各自使用不同事件 ID。本函数只发送已经确认的结果，不扣款、不验证支付平台签名，也不把监控失败回滚成支付失败。不得在浏览器、支付按钮点击或成功页刷新时调用，不自动发给 Plausible。

OAuth 和邮箱验证流程中，将经过验证且有大小上限的上下文保存在已有服务端认证会话或既有 state 记录关联的数据里；不要替换 OAuth state、跳过签名或信任回调 URL 中的身份。成功后随真实注册完成保存，登录、刷新成功页面不等于新增注册。订单/付款归因随真实订单记录关联，支付确认来自已验签 webhook 或支付服务后端。

所有保存、绑定与查询都包含 `site_id`，唯一关系至少是 `(site_id,user_id)`；订单也在对应站点下核验归属。跨站同名 user_id 不自动关联。Collector 提供事件存储与查询，实际用户-归因关系仍由现有业务数据库保存，避免监控服务替代账户系统。

浏览器 `Signup` Goal 是分析信号，后端 `signup_confirmed` 是可信接入记录；两者不自动互转。后端事件本版完全不会发送 Plausible。付款事件同理。真实接入时将 server token 存在后端环境变量，永不放入前端配置或静态 HTML。

运行 `node --test tests/backend.test.ts` 可验证测试替身：站点不匹配/伪造身份线索被忽略，同一后端 eventId 重发只写一行，查询显示 `received_via:'server'`。

## Business 插件集成（0.1.1）

后端 `@app/auth-sdk/monitor` 导出 `createMonitorOptions()` 和 `startMonitorWorker()`；`@app/auth-sdk/monitor/client` 导出 `monitorHeaders()`。将 `auth-sdk.tgz` 和固定版本的 `monitor-analytics-sdk-0.1.1.tgz` 复制到网站 vendor 后用 pnpm 安装，不引用开发机器仓库路径。

浏览器在邮箱注册、已有 OAuth 渠道发起和创建订单时，将 `monitorHeaders(monitor.getAttributionContext())` 放入请求 fetchOptions.headers。`X-Monitor-Context` 为 base64url JSON，编码后最多 4 KiB。没有许可或非法上下文时省略，业务继续。服务端通过 `registrationClues` 重新校验本站 ID、精确 origin、公共路径及结构。

网站环境变量为 `APP_MONITOR_ENABLED=true`、`APP_MONITOR_SITE_ID`、`APP_MONITOR_ENDPOINT`（完整 /v1/server-events）、`APP_MONITOR_TOKEN`、`APP_MONITOR_ENVIRONMENT`、`APP_MONITOR_ORIGINS_JSON`、`APP_MONITOR_ALLOWED_PATHS_JSON`。Collector 继续使用自身 MONITOR_* 配置。`APP_MONITOR_RETRY_WINDOW_DAYS` 默认 7；`APP_MONITOR_COLLECTOR_RETENTION_DAYS` 默认 30，必须匹配实际保留期且严格大于补发窗口。

真实新用户 insert 同时保存内部注册快照与待入队标记；后台事务创建投递记录并清除标记。OAuth 用现有受保护 serverContext 携带归因；登录、邮箱验证、重复注册、管理员建号不计数。订单保存第一次购买的归因，付款与监控记录同事务保存，履约失败仍可报告付款。缺少当前来源不借用旧注册来源；已有续费继承原订单归因。

Dashboard Node instrumentation 每 60 秒调度一轮，最多 20 条、并发 2，通过数据库租约恢复进程中断。补发沿用原 UUID、时间和载荷，不重新确认付款或发放权益。Collector 故障影响投递状态；本地记录写入失败必须使付款事务失败，并由原有流程恢复。首次启用不补历史；关闭暂停采集和投递并保留记录。

调用签名保持不变；0.1.1 增加 `CollectorSendError` 类型，包含 code、retryable、可选 status/retryAfterMs，不含响应正文、凭证或原始网络错误。

| code | 处理 |
| --- | --- |
| collector_network_error | 网络或 5 秒超时，可重试 |
| collector_http_error | 仅 429、5xx 可自动重试，遵守 Retry-After |
| collector_invalid_receipt | 回执无效，人工排查 |
| collector_invalid_record | 本地事件不符合协议，人工排查 |

Business 对网络/429/5xx 最多自动尝试 8 次；其他失败进入 failed。策略变更使旧归因无效时标记 monitor_policy_changed，不静默改变载荷。已送达或超过补发期不允许人工重送。面板只显示凭证是否配置，查询与补发由 monitor:read / monitor:retry 及现有审计保护。

服务端构建使用 ES2022 和纯 Web API，不导入 Node 内置模块；Collector 和开发工具继续使用 Node 24。运行 `pnpm exec node --test tests/backend.test.ts` 验证发送协议。在后端仓库执行 `pnpm build:sdk`，设置 `MONITOR_COLLECTOR_PATH` 指向独立接收服务后运行 `pnpm test:monitor:integration`，以临时业务库和 Collector 库验证独立安装包、实际入库、received_via='server'、并发付款去重及丢失本地确认后的恢复。
