# 本版示例所需 Plausible Goals

| SDK 事件 | Plausible Custom Event Goal 名称 | 允许的属性 | 配置示例 |
|---|---|---|---|
| `tool_completed` | `Tool Completed` | `tool`, `result` | 静态站和模块导入示例 |
| `signup_completed` | `Signup` | `method` | 有用户系统的模块示例 |

在测试站的 Plausible 网站设置 → Goals 中创建 Custom Event，名称大小写和空格必须与映射一致。发送自定义事件不会自动创建 Goal。上线前重新导出/核对现有 Goal，防止重复命名。不要在每次登录或刷新成功页时调用 signup_completed；只有真实新注册完成且取得相应许可才发送一次。

`pageview` 由官方自动采集，不再手动调用；本版不为镜像创建额外 Goal。没有映射的自有事件只进入 Collector。删除某条 customEvents 映射即可关闭该事件到 Plausible 的发送；`customEvents:{}` 关闭全部业务转发，Collector 不受影响。错误、性能、身份、付款类事件禁止映射。

[官方 Custom Event Goal 配置说明](https://plausible.io/docs/custom-event-goals)
