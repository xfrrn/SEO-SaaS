# Plausible 兼容性核验（2026-10-08）

仓库开始时为空且无提交，配置的 GitHub origin 也没有远端分支：没有原有前端框架、统计脚本、Collector、Backend SDK、部署配置或 Goal 清单。无法从仓库确认用户目前使用官方托管还是自部署、服务端版本、生产脚本版本或重复采集入口。本次验证针对锁定的官方 npm 包和本地模拟接收端，不代表生产 Plausible 已联调通过。

## 已验证的官方版本

采用 `@plausible-analytics/tracker@0.4.6`，2026-08-10 发布，官方浏览器 payload 的版本字段为 `36`。依赖固定版本并由 lockfile 校验完整性。官方源码与发布包都提供同步 `transformRequest(payload): payload | null`，在首次自动 pageview 之前通过 `init` 配置；过滤结果为空则不发送。[官方配置文档](https://plausible.io/docs/script-extensions)、[类型定义](https://github.com/plausible/analytics/blob/master/tracker/npm_package/plausible.d.ts)、[npm 包](https://www.npmjs.com/package/@plausible-analytics/tracker/v/0.4.6)。

适配器动态导入官方包，官方包单独构建成 chunk；未启用时不加载。只使用官方 `init`、`track`，不实现 Plausible 协议、访客识别或 SPA pageview 采集，不修改官方源码，也不拦截网络。初始化配置先就位，随后由官方自动产生首屏事件。服务端导入 SDK 不访问浏览器对象。

镜像仅复制经过原有过滤、SDK 隐私处理后允许的事件，默认白名单为 `pageview`，只读取 `n/u/d/r`；不复制原始 props、收入或未知字段。Collector 由自己的上下文与协议构造事件。映射业务事件经独立路径调用官方接口，不再镜像回 Collector。镜像失败保留原发送，隐私过滤失败则拒绝该事件。

## 必须保留的上游限制

**0.4.6 无法仅靠公开 Hook 实现页面内的完整动态撤回。** 已允许的 pageview 会启用 engagement 统计，engagement 在失焦/页面隐藏时直接发送，绕过 `transformRequest`；公开 API 没有 `destroy`、`stop` 或关闭 engagement 的选项。[官方 engagement 源码](https://github.com/plausible/analytics/blob/master/tracker/src/engagement.js)、[公开 API](https://github.com/plausible/analytics/blob/master/tracker/npm_package/plausible.d.ts)。

可执行测试使用实际发布包重现：Hook 收到 `pageview`，撤回后失焦，发送端仍收到 `engagement`。`@plausible-analytics/tracker@0.3.6` 的实际发布包也存在同一行为，并在模块导入时读取 `window/location`，降级不能解决问题。官方 changelog 标记 Hook 于早期 `0.2.2` 加入，不代表任意历史自部署脚本都支持该能力。[官方 changelog](https://github.com/plausible/analytics/blob/master/tracker/npm_package/CHANGELOG.md)。

- `consentMode: "strict"` 是默认值：报告 `unsupported_consent`，不加载、不初始化此 Plausible 版本；Collector、工具事件、归因和其他允许的模块继续独立工作。
- `consentMode: "page-lifetime"` 必须显式设置：用于许可在当前页面生命周期内有效的场景。撤回时停止 SDK 的新映射事件与新镜像、清除待发送映射队列，并通过 Hook 拒绝后续 pageview/custom event；报告 `plausible_engagement_may_continue`，不能承诺已启动的 engagement 立即停止。SDK 不强制刷新页面，也不偷偷修改全局网络或官方内部函数。
- 需要完整即时撤回的部署应保持 strict，等待官方提供能覆盖 engagement 的公开控制接口，再重新执行该回归测试；不要把 page-lifetime 当成等价的 consent 实现。

`trackerVersion` 不等于已验证的 `0.4.6` 时，报告 `unsupported_version`。页面已经存在 `window.plausible`、含 plausible 的 script 地址或 `data-domain` 脚本时，报告 `migration_required` 并拒绝重复安装。SDK 不会猜测旧脚本的 Hook 能力或补发首屏 pageview。根入口通过页面生命周期单例避免重复挂载与 HMR 再次初始化。

## 已完成与生产验证边界

自动化测试使用真实官方模块和本地模拟端点，验证首屏 pageview/镜像各一份、映射事件一次、未映射不转发、过滤拒绝不镜像、镜像异常不阻塞 Plausible、事件页面快照，以及官方撤回限制。测试中的网络替身仅用于断言，生产实现没有网络拦截。

生产接入前需要在测试站完成以下检查：

1. 记录托管类型、服务端版本、现有 script/npm 版本、加载入口及配置，检查框架插件、GTM、手动 pageview 和重复标签；删除原入口后再启用 SDK。
2. 将现有 `transformRequest` 迁移到 SDK 的同名配置，保留过滤规则；整理自定义属性白名单，验证路径脱敏和正常访问来源。
3. 确認自部署 Events API 与锁定 tracker 的 pageview/custom/engagement 行为兼容。浏览器 Hook 兼容不等于服务端兼容。
4. 在 Plausible 后台创建名称完全匹配的 Custom Event Goal。本例需要 `Tool Completed`；如果启用 `signup_completed` 映射，还需 `Signup`。调用 `track` 不会创建 Goal。[Goal 配置说明](https://plausible.io/docs/custom-event-goals)。
5. 在测试站同时检查网络请求、Collector 查询结果、Plausible 实时/目标报表及过滤信息。Events API 即使丢弃事件也可能返回 `202`；检查 `x-plausible-dropped: 1`，不要只凭状态码宣布成功。[Events API 调试说明](https://plausible.io/docs/events-api)。

没有收到真实 Plausible 测试站的地址、部署资料或凭据，因此生产版本核验、真实报表确认及真实 Backend SDK 联调仍未完成。

## 第三方脚本体积

对安装的 `node_modules/@plausible-analytics/tracker/plausible.js` 实测：原文件 **6,434 字节**，gzip level 9 **2,670 字节**，Brotli 默认参数 **2,355 字节**。构建后的官方独立 chunk 还可能包含构建工具包装；最终构建报告应单列该 chunk，不能只报告 Monitor 核心体积。

发布包完整性：`sha512-nbu6xGgSP6jeYuoVklZBzucUnIpo75tVu3Kr+R0EDycVKaMC/jF5Q/YCaM/8gR4fPZ1IDcXt6FdBJFZ1uZwEPA==`。
