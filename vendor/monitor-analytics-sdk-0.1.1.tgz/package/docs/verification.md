# 验收记录（2026-10-08，Asia/Shanghai）

在 Windows / Node 24.20.0 / 实际 Chrome 上验证：**类型检查通过，38 项 Node 测试通过，15 项浏览器测试通过，构建成功**。额外两项独立 Monitor 接收端联调通过。CI 已配置 Node 24 + Linux Chromium；本次没有宣称远端 CI 已运行。

本轮联调修复了三处 SDK 问题，均先复现失败再修复：身份存储 JSON 损坏或读取异常时缺失内存 UUID；41–64 字符的合法属性名被投影丢弃；存储中的大写/缩写 IPv4 来源主机未规范化，导致实际接收端拒收。新增回归覆盖稳定的内存身份、属性名长度边界、来源规范化和大小写无关的排除规则。实际接收端联调同时验证 64 字符属性与规范化来源成功入库。

## 覆盖与证据

| 验收场景 | 验证 |
|---|---|
| 首屏自动 pageview、单向镜像 | 真实官方包，Plausible 模拟端点一份；Collector 实际 SQLite 一份 |
| 重复 init、组件重挂、HMR | 浏览器单例复用，官方初始 pageview 一次 |
| 映射/未映射 track | Collector 各一份；仅配置的自定义事件进入 Plausible，无重复镜像 |
| 立即 track、模块仍在加载 | 有界独立启动队列；固定 URL/props |
| Plausible 下载被阻止 | 工具事件、错误、归因仍工作 |
| Collector 503、重试/终止、400 | ID 保持、次数有上限、不重放 Plausible |
| HTML 200、错误或不完整回执 | 不计成功；原 ID 重试；合法 duplicates 回执可确认交付 |
| 在途请求新增事件、429 等待 | 新事件不能绕过当前请求的 Retry-After |
| 在途撤回后立即重新许可 | 旧快照丢弃，新事件仍能自动调度 |
| SPA 路由、延迟发送 | 旧事件仍关联原页面；由官方产生新路由 pageview |
| 存储禁用、初始拒绝、运行中撤回 | 内存降级；清理队列/存储、停止错误监听 |
| 加载期间撤回 | 动态 import 完成后不会重新恢复存储或发送 |
| 身份关闭 | 无 visitor_id/session_id，无 Backend SDK 依赖 |
| 同 ID 重交、跨站、重启 | SQLite 唯一约束、站点隔离、持久化数据保留 |
| 浏览器伪造身份、后端无权限 | 严格结构拒绝；Bearer 站点/事件/read 作用域 |
| 旧版/未知版本、已有脚本 | unsupported_version/migration_required，拒绝重复初始化 |
| URL/props/已有过滤 | 敏感内容、未知字段和收入排除；拒绝事件不镜像；镜像异常不阻塞主链路 |
| 绕过 SDK 提交敏感路径 | Collector 独立按站点校验页面及全部归因落地页路径白名单 |
| first/last 来源、站内/unknown 回访、auth/payment | 首次不被覆盖，归因窗口/TTL生效，内部返回排除 |
| 畸形持久化数据 | 枚举/ISO时间/UUID校验，避免污染批次 |
| 后端注册测试替身 | 使用已提交身份/站点，stable eventId 幂等，查询确认 server 入口 |
| 专门付款发送函数 | 非法金额/币种/身份/时间/UUID 在联网前拒绝；仅投影允许字段；同付款 ID 幂等；失败返回已有 outbox |
| SDK 与接收端协议差异 | 站点 ID 规则统一；非法归因来源/UTM 丢弃，不拖累注册事件 |

浏览器测试包含真实 `examples/static.html` → SDK → 官方 Tracker → 本地 Plausible 模拟端点，以及 SDK → HTTP → 实际 SQLite 的完整链路，未使用 mock Collector 代替此项验收。其他故障测试只替换目标 HTTP 端点或阻止脚本加载，生产实现不存在网络拦截。

另已执行 `npm pack`，在独立临时消费项目中安装生成的 tgz，关闭 skipLibCheck 进行 TypeScript 检查并运行 Node SSR 导入：均通过。已打包的文件没有过期构建 chunk；官方类型依赖随 package dependencies 安装。

新增 `monitor-analytics-sdk/server` 子路径也完成打包后的独立消费验证：`ConfirmedPayment` 类型检查通过，运行实际包的 `sendConfirmedPayment()` 得到正确事件/身份/金额字段，SSR 导入正常。服务端入口没有被任何浏览器入口或 chunk 引用。

**未完成的真实联调：** 当前 Plausible 托管类型、服务端版本、原脚本/插件及 Goal 都无法从空仓库确认；没有真实测试站后台报表、过滤 header、注册或支付环境的验收结果。模拟端点的 202 仅证明请求形状/次数，不证明 Plausible 统计收录。

**未满足的上游能力：** 实际官方 0.4.6 在撤回后仍可能发送 engagement，回归测试明确复现。strict 默认不启动它；page-lifetime 是有限兼容模式。没有通过改源码、网络拦截或补发 pageview 隐藏问题。hashBasedRouting 的片段也始终被脱敏，第一版不提供 hash 页面细分；常规 History API SPA 路由已经验证。

## 独立 Monitor 接收服务联调

接收端位置：`D:\codes\EgooAI\SEO-Worker\apps\collectors\monitor`。直接导入该服务的 `src/server.ts` 和 `src/schema.ts`，不替换为 SDK 内的示例 Collector。使用独立本机端口、临时文件 SQLite、随机读写凭证；测试结束关闭服务并清理测试目录，不读取生产 `.env`。

在 SDK 仓库运行（需要 Node 24、已安装 npm 依赖和 Chrome，其他浏览器通道见 README）：

```powershell
$env:MONITOR_COLLECTOR_PATH = 'D:\codes\EgooAI\SEO-Worker\apps\collectors\monitor'
npm run test:receiver
```

该命令先构建 SDK，再运行 `tests/receiver.integration.ts`。两项测试验证真实 Chrome → 跨域 HTTP → 接收服务 → SQLite → 鉴权查询；首屏与 SPA pageview 各一份、映射事件不再镜像、独立工具/错误/性能事件、早期快照不被补改身份、后端注册/付款及幂等。最终保存 7 条浏览器事件和 3 条可信入口事件，其中一条注册的非法归因被剔除、业务事件仍入库。还验证缺少或错误凭证、错误站点、伪造入口、读写越权、坏批次被拒绝及撤回后停止入库。

接收端自身 `npm run check`、22 项 `npm test` 及 `MONITOR_SDK_PATH` 指向本仓库后的 1 项 `npm run test:sdk` 也通过。此次确认的缺陷位于 SDK/后端发送示例，接收服务代码无需修改。

实际网站配置时应同步下列字段；本测试使用临时配置，不替你填生产地址或密钥：

| SDK / 业务后端 | 接收服务 `.env` 中的对应配置 |
|---|---|
| `siteId` | `MONITOR_SITES_JSON` 的站点键 |
| 网站实际 origin（协议、域名、端口） | 该站点 `origins` |
| `privacy.allowedPaths`；后端 `destination.allowedPaths` | 该站点 `allowedPaths` |
| 后端 `destination.origins` | 该站点 `origins` |
| `collector.events`、镜像 pageview | 该站点 `browserEvents`、`mirrorEvents` |
| `collector.endpoint` | 接收服务公开 HTTPS 地址 + `/v1/browser-events` |
| 后端 endpoint / token | `/v1/server-events`；`MONITOR_CREDENTIALS_JSON` 引用的写入凭证 |

Plausible 使用官方 0.4.6 脚本加本地模拟 HTTP 端点；注册/付款使用业务记录测试替身。付款链路调用实际 `sendConfirmedPayment()`，重复调用验证 `duplicates:1`，鉴权查询核对订单、金额、币种与归因。这证明接收协议和实际存储可用，不等于 Plausible 生产报表或真实支付 webhook 已验收。

## 构建体积（字节）

`npm run build` 使用 esbuild minify，Node zlib 默认 gzip/Brotli。核心统计将入口全部静态依赖相加，gzip/Brotli 按每个实际文件分别压缩后求和，未把 165 B 的入口当成完整成本。可选模块一列是核心之外的增量，共享依赖只算一次。

| 部分 | raw | gzip | Brotli |
|---|---:|---:|---:|
| 核心 ESM（含配置校验、传输、隐私、identity与性能扩展） | 13,899 | 6,088 | 5,417 |
| HTML 脚本入口核心（代替上一行） | 13,920 | 6,087 | 5,405 |
| 可选 Attribution | 3,152 | 1,447 | 1,285 |
| 可选 Errors | 684 | 398 | 338 |
| 可选 Plausible 适配器 | 2,750 | 1,301 | 1,162 |
| 官方 Tracker 独立构建 chunk | 6,117 | 2,608 | 2,303 |
| 浏览器全部启用，ESM入口合计 | 26,602 | 11,842 | 10,505 |
| 独立服务端入口（不计入浏览器） | 7,190 | 2,888 | 2,558 |

官方 npm 原始 JS 为 6,434 B / gzip 默认 2,672 B / Brotli 2,355 B。与兼容性文档的 gzip level 9（2,670 B）压缩参数不同。最终细项与模块来源见构建产物 `dist/sizes.json` 和 `dist/metafile.json`。网络 HTTP 头、TLS 和缓存不计入代码体积；部署时应启用压缩与对带 hash 的 chunks 长期缓存，入口使用可更新缓存策略。
