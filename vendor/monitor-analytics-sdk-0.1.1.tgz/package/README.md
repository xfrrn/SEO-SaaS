# Monitor Analytics SDK

可运行的第一版：统一浏览器入口、Plausible 单向镜像、独立 Collector、可选归因与后端上下文桥接。原仓库为空，因此保留当前仓库并新增一个 TypeScript 包；没有重建登录、支付或报表后台。

**兼容性边界：** 官方 `@plausible-analytics/tracker@0.4.6` 支持镜像 Hook，但其 engagement 绕过 Hook，缺少公开停止接口。默认 `strict` 模式不会启动该版本的 Plausible；Collector、归因、错误仍可使用。静态测试页显式采用 `page-lifetime` 模式来验证镜像，它不满足即时完整撤回要求。详见 [核验结果与迁移步骤](docs/compatibility.md)。真实 Plausible 部署信息和 Backend SDK 尚未提供，不能宣称生产联调完成。

## 运行和验证

需要 Node.js 24+。浏览器需支持 ES2022、ES modules、fetch、Web Crypto 和 ResizeObserver；使用 HTTPS 或 localhost。

```powershell
npm ci
npm run typecheck
npm test
npm run build
npm run demo
```

打开 `http://127.0.0.1:4173`，点击“完成一次工具操作”。页面显示 SDK 诊断和实际 SQLite 接收结果；Plausible 使用本地模拟端点，不会写入生产服务。该服务只绑定 loopback、使用临时内存数据库，`/demo/state` 仅为本地调试，**不要用于生产部署**。

```powershell
# Windows 默认使用已安装 Chrome；没有 Chrome 时安装 Chromium 并指定通道。
npx playwright install chromium
$env:PLAYWRIGHT_CHANNEL = 'chromium'
npm run test:browser
# 全量验收（包括构建）
npm run check
```

Linux CI 使用 Playwright Chromium。测试使用原生 Node test 和 Playwright；生产代码没有测试替身、fetch/XHR/sendBeacon 拦截。包括真实官方 Tracker → 模拟 Plausible 端点、SDK → 真实 SQLite Collector、后端鉴权测试替身；不把 202 当作真实报表成功。[验收记录](docs/verification.md)

## 普通 HTML：一个监控入口

把整个 `dist/`（包括 `chunks/`）部署到自己的静态资源目录；不要只复制入口文件。`monitor.js` 是 ESM 脚本，不是必须塞进全部模块的单文件。

```html
<script>
window.monitorConfig = {
  siteId: 'my-tool', environment: 'production',
  collector: {
    endpoint: 'https://metrics.example.com/v1/browser-events',
    events: { tool_completed: ['tool', 'result'] }
  },
  privacy: {
    allowedPaths: ['/', '/tools/webp-to-png'],
    propValues: { tool: ['webp-to-png'], result: ['success', 'failure'] }
  },
  consent: { collector: true } // 由你的网站许可策略确定；缺省全部为 false
};
</script>
<script type="module" src="/analytics/monitor.js"></script>
<script type="module">
// 在业务真正完成的位置调用。
window.monitor.track('tool_completed', { tool: 'webp-to-png', result: 'success' });
</script>
```

这是无需任何 Backend SDK 的静态站基础接入。完整的本地 Plausible + Collector 脚本示例见 [examples/static.html](examples/static.html)。生产 CSP 至少允许自托管模块的 script-src 与 Collector/Plausible 的 connect-src；将示例内联配置移入同源 JS 或使用 nonce，不要放宽为任意脚本执行。

## 模块导入和公开 API

```typescript
import { monitor } from 'monitor-analytics-sdk';
monitor.init(config);                  // 同页面同配置重复调用复用单例
await monitor.ready();                 // 可选：等待模块状态稳定，以便读取完整归因
monitor.track('tool_completed', { tool: 'webp-to-png', result: 'success' });
const clues = monitor.getAttributionContext(); // 未启用时 undefined；不是身份凭证
await monitor.setConsent({ collector: false, attribution: false, storage: false });
await monitor.flush();                 // 发送当前批次；其余批次继续调度，失败有限重试
console.log(monitor.getDiagnostics()); // 最多 30 条无事件内容的诊断
```

已提供 [框架客户端入口示例](examples/framework.ts)。从框架根组件的客户端生命周期调用；SSR 导入/初始化不采集。`init()` 会对冲突映射、敏感字段和非法配置抛出错误，便于开发时立即修正；正常采集、模块加载或网络失败只记诊断，不抛给业务。组件卸载不要撤销全站许可；生命周期状态保存在页面单例，HMR 不重复安装官方 Tracker。

业务后端可从 `monitor-analytics-sdk/server` 导入 `sendConfirmedPayment()` 和 `sendConfirmedRegistration()`，发送已经确认的付款/注册事件。服务端入口独立构建，不增加前端下载量；付款金额采用最小货币单位整数，身份、订单和事件 ID 由后端确认并保存。调用方式见 [付款事件函数](docs/backend.md#专门的付款事件函数)。

`track()` 可以紧接 `init()` 使用：Collector 立即捕获快照，映射的 Plausible 事件有独立有界启动队列（50 条）；加载失败后不重放业务入口。尚未加载完成的归因不会追溯改写早期事件，需要完整上下文时使用 `ready()`。`getDiagnostics().collector.delivered` 表示收到有效的 Collector 回执（`accepted + duplicates` 等于本批条数），错误地址返回 HTML 200 或不完整回执不会算作成功，报表验收仍需查询数据库。官方模块状态 `ready` 表示成功初始化，不代表生产报表已收录。

可在本仓库构建后 `npm pack`，在其他项目用生成的包文件安装；本仓库 `private:true` 防止意外发布。正式发布前填写组织包名/许可证并决定发布权限，不会擅自发布 npm。

## 按需模块与许可

| 场景 | 配置 |
|---|---|
| 静态工具站 | Collector 事件白名单；按兼容能力选择 Plausible；可选 errors |
| 获客工具站 | 再启用 modules.attribution，默认 persistence:none |
| 用户归因 | 再启用归因持久化/identity，将桥接上下文随真实业务请求交给后端 |
| SaaS | 复用真实注册/支付后端，从鉴权入口发送可信事件 |

许可位为 `collector / plausible / attribution / storage / identity / errors / performance`，缺省 false。模块配置与许可必须同时满足。identity 还要求 Collector 和 storage 许可，默认不产生任何持久化 ID。存储按站点+origin 隔离，TTL 和归因窗口可配置。撤回任一上下文/模块许可会清空 Collector 待发快照；归因/存储撤回清理相应两种存储，关闭错误监听。已经到达服务端的请求无法靠浏览器撤回删除；服务端按保留期清理。

错误模块只发 `kind` 和标准 `error_type`，不发原始消息、堆栈、文件内容或 URL，每分钟最多 10 条。性能第一版保留显式扩展入口 `recordPerformance('LCP'|'CLS'|'INP', value)`；配置 `performance:['metric','value']`，启用模块及许可后才采集，完全不转发 Plausible。它不会自动安装性能观察器。没有录像、热力图、DOM/表单/点击全采集或任意远程 JS 执行。

## Collector

已与 `SEO-Worker/apps/collectors/monitor` 独立接收服务完成本地 Chrome / CORS / SQLite 联调，接入该服务时在其 `.env` 配置站点和凭证，SDK 指向它的 `/v1/browser-events`。可复现命令、配置对应关系见 [接收服务联调记录](docs/verification.md#独立-monitor-接收服务联调)。下面的 `collector/` 仍可用于本仓库本地示例。

最小服务使用 Node 原生 HTTP + SQLite WAL，公开浏览器入口与有 Bearer 鉴权的后端入口分开。浏览器公开 siteId 不是凭证；CORS/Origin 只限制接入，不证明用户身份。

```powershell
# 自行生成并在环境/密钥管理中保存至少 32 字符的随机 token。
$env:MONITOR_COLLECTOR_TOKEN = '<server-only-random-token>'
npm run collector -- collector/config.example.json
```

复制并修改站点 origins/events/allowedPaths/凭证作用域；默认绑定 127.0.0.1:8787，部署时使用既有 HTTPS 反向代理。浏览器与 Collector 的公开路径白名单需对应，接收端拒绝额外路径。静态站域名必须与配置 origin 完全匹配。密钥只存在服务端。完整接口、查询与代理部署说明见 [Collector 文档](collector/README.md)。

客户端默认队列 100 条/128,000 字节，单批 20 条/48,000 字节，5 秒调度、8 秒超时、最多 3 次重试（共 4 次尝试），指数退避最多 30 秒并尊重上限 60 秒的 Retry-After。页面隐藏/退出尝试 keepalive。队列内存保存，不承诺不丢失或离线可靠交付；Collector 故障不会重发 Plausible。

## 交付索引

- [导入、函数与事件调用指南（含对照表）](docs/integration-guide.md)
- [事件和上下文协议](docs/protocol.md)
- [Plausible 兼容与迁移](docs/compatibility.md)
- [Goal 清单](docs/goals.md)
- [Backend SDK 对接及测试替身](docs/backend.md)
- [验收与构建体积](docs/verification.md)

`npm run build` 每次实测 raw/gzip/Brotli 并写入 `dist/sizes.json`，包含每个 chunk 的源文件和依赖。入口文件的几十字节不是核心总成本：应将所有静态依赖相加，并单列可选模块与官方 Tracker。
